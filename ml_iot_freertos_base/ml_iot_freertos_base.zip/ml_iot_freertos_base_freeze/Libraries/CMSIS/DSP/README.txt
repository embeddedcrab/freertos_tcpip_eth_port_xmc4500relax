
1. Using the Statis Library in Build
2. Not using the Source files but Include Folder files
